// Build: included by translation units built with cl /std:c++latest /O2 /W4 /WX /permissive-
// MODULE: ThreadTracker
// ERROR-POLICY: expected
// Reason: thread observation failures are recoverable Win32/runtime conditions.

#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <Windows.h>
#include <chrono>
#include <cstdint>
#include <expected>
#include <optional>
#include <unordered_map>
#include <vector>

#include "ErrorCode.h"
#include "ThreadInfo.h"
#include "WinHandle.h"

namespace ThreadTrackerPolicy
{
    inline constexpr auto kDefaultStickinessDuration = std::chrono::milliseconds(4000);
    inline constexpr auto kMaxStickinessDuration = std::chrono::milliseconds(7000);
    inline constexpr auto kStickyUpStep = std::chrono::milliseconds(1000);
}

struct ThreadTrackerConfig
{
    double emaAlpha = 0.25;
    std::chrono::milliseconds stickinessDuration = ThreadTrackerPolicy::kDefaultStickinessDuration;
    int sampleCount = 3;
    std::chrono::milliseconds sampleInterval = std::chrono::milliseconds(50);
};

class ThreadTracker
{
public:
    explicit ThreadTracker(
        DWORD processId,
        ThreadTrackerConfig config = ThreadTrackerConfig{}) noexcept;

    [[nodiscard]] std::expected<void, ErrorCode> update() noexcept;

    [[nodiscard]] std::expected<std::vector<ThreadInfo>, ErrorCode>
    getTopThreads(std::size_t maxCount) const noexcept;

    [[nodiscard]] std::optional<DWORD> getEmaCandidateThreadId() const noexcept;
    [[nodiscard]] std::optional<DWORD> getMainThreadId() const noexcept;
    [[nodiscard]] int consumeThreadMigrationCount() noexcept;
    void increaseStickinessBy(std::chrono::milliseconds delta) noexcept;


private:
    struct ThreadSample
    {
        WinHandle threadHandle;
        std::uint64_t previousCpuTime100ns = 0;
        std::uint64_t currentCpuTime100ns = 0;
        std::uint64_t deltaCpuTime100ns = 0;
        std::uint64_t accumulatedDelta100ns = 0;
        int accumulatedDeltaCount = 0;
        double emaCpuTime100ns = 0.0;
        bool hasEma = false;
    };

    [[nodiscard]] static std::expected<std::uint64_t, ErrorCode>
    queryThreadCpuTime100ns(HANDLE threadHandle) noexcept;

    [[nodiscard]] static std::uint64_t fileTimeToUint64(const FILETIME& fileTime) noexcept;

    [[nodiscard]] std::expected<WinHandle, ErrorCode> openThreadHandle(DWORD threadId) const noexcept;
    [[nodiscard]] std::expected<void, ErrorCode> observeOnce() noexcept;
    void finalizeMultiSample() noexcept;
    void resetMultiSampleAccumulators() noexcept;

    void updateCandidateState(std::chrono::steady_clock::time_point now) noexcept;
    void resetCandidateState() noexcept;

private:
    DWORD processId_ = 0;
    ThreadTrackerConfig config_;
    std::unordered_map<DWORD, ThreadSample> samples_;
    std::optional<DWORD> emaCandidateThreadId_;
    std::optional<DWORD> mainThreadId_;
    std::optional<DWORD> lastConfirmedMainThreadId_;
    std::optional<std::chrono::steady_clock::time_point> candidateStartedAt_;
    int threadMigrationCount_ = 0;
};
