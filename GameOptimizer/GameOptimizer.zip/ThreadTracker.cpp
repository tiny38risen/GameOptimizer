// Build: cl /std:c++latest /O2 /W4 /WX /permissive- ThreadTracker.cpp
// MODULE: ThreadTracker
// ERROR-POLICY: expected
// Reason: thread observation failures are recoverable Win32/runtime conditions.

#include "ThreadTracker.h"

#include <TlHelp32.h>
#include <algorithm>
#include <chrono>
#include <new>
#include <thread>
#include <unordered_set>
#include <utility>

#include "Logger.h"
#include "WinApiError.h"

ThreadTracker::ThreadTracker(
    DWORD processId,
    ThreadTrackerConfig config) noexcept
    : processId_(processId),
      config_(config)
{
}

std::uint64_t ThreadTracker::fileTimeToUint64(const FILETIME& fileTime) noexcept
{
    ULARGE_INTEGER value{};
    value.LowPart = fileTime.dwLowDateTime;
    value.HighPart = fileTime.dwHighDateTime;

    return value.QuadPart;
}

std::expected<std::uint64_t, ErrorCode>
ThreadTracker::queryThreadCpuTime100ns(HANDLE threadHandle) noexcept
{
    FILETIME creationTime{};
    FILETIME exitTime{};
    FILETIME kernelTime{};
    FILETIME userTime{};

    if (!GetThreadTimes(
            threadHandle,
            &creationTime,
            &exitTime,
            &kernelTime,
            &userTime))
    {
        const DWORD lastError = GetLastError();
        if (lastError == ERROR_ACCESS_DENIED)
        {
            return std::unexpected(ErrorCode::AccessDenied);
        }

        return std::unexpected(ErrorCode::ThreadTimeQueryFailed);
    }

    return fileTimeToUint64(kernelTime) + fileTimeToUint64(userTime);
}

std::expected<WinHandle, ErrorCode>
ThreadTracker::openThreadHandle(DWORD threadId) const noexcept
{
    WinHandle threadHandle(OpenThread(
        THREAD_QUERY_LIMITED_INFORMATION,
        FALSE,
        threadId));

    if (!threadHandle)
    {
        return std::unexpected(mapLastErrorToErrorCode(GetLastError()));
    }

    return threadHandle;
}

void ThreadTracker::resetMultiSampleAccumulators() noexcept
{
    for (auto& [threadId, sample] : samples_)
    {
        sample.accumulatedDelta100ns = 0;
        sample.accumulatedDeltaCount = 0;
    }
}

std::expected<void, ErrorCode> ThreadTracker::observeOnce() noexcept
{
    try
    {
    WinHandle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0));
        if (!snapshot)
        {
            return std::unexpected(ErrorCode::SnapshotCreationFailed);
        }
    
        std::unordered_set<DWORD> activeThreadIds;
    
        THREADENTRY32 entry{};
        entry.dwSize = sizeof(entry);
    
        if (!Thread32First(snapshot.get(), &entry))
        {
            const DWORD lastError = GetLastError();
            if (lastError == ERROR_NO_MORE_FILES)
            {
                samples_.clear();
                resetCandidateState();
                return {};
            }
    
            return std::unexpected(ErrorCode::EnumerationFailed);
        }
    
        do
        {
            if (entry.th32OwnerProcessID != processId_)
            {
                continue;
            }
    
            activeThreadIds.insert(entry.th32ThreadID);
    
            ThreadSample& sample = samples_[entry.th32ThreadID];
    
            if (!sample.threadHandle)
            {
                auto openedHandle = openThreadHandle(entry.th32ThreadID);
                if (!openedHandle)
                {
                    continue;
                }
    
                sample.threadHandle = std::move(*openedHandle);
            }
    
            const auto currentCpuTime = queryThreadCpuTime100ns(sample.threadHandle.get());
            if (!currentCpuTime)
            {
                sample.threadHandle.reset();
                continue;
            }
    
            sample.currentCpuTime100ns = *currentCpuTime;
    
            if (sample.previousCpuTime100ns != 0 &&
                sample.currentCpuTime100ns >= sample.previousCpuTime100ns)
            {
                const std::uint64_t delta =
                    sample.currentCpuTime100ns - sample.previousCpuTime100ns;
                sample.accumulatedDelta100ns += delta;
                ++sample.accumulatedDeltaCount;
            }
    
            sample.previousCpuTime100ns = sample.currentCpuTime100ns;
        }
        while (Thread32Next(snapshot.get(), &entry));
    
        const DWORD lastError = GetLastError();
        if (lastError != ERROR_NO_MORE_FILES)
        {
            return std::unexpected(ErrorCode::EnumerationFailed);
        }
    
        std::erase_if(
            samples_,
            [&activeThreadIds](const auto& sampleEntry)
            {
                return !activeThreadIds.contains(sampleEntry.first);
            });
    
        return {};
    
    }
    catch (const std::bad_alloc&)
    {
        return std::unexpected(ErrorCode::AllocationFailed);
    }
    catch (...)
    {
        return std::unexpected(ErrorCode::InternalError);
    }
}

void ThreadTracker::finalizeMultiSample() noexcept
{
    for (auto& [threadId, sample] : samples_)
    {
        if (sample.accumulatedDeltaCount <= 0)
        {
            sample.deltaCpuTime100ns = 0;
            continue;
        }

        sample.deltaCpuTime100ns =
            sample.accumulatedDelta100ns / static_cast<std::uint64_t>(sample.accumulatedDeltaCount);

        const double currentDelta = static_cast<double>(sample.deltaCpuTime100ns);
        if (sample.hasEma)
        {
            sample.emaCpuTime100ns =
                (config_.emaAlpha * currentDelta) +
                ((1.0 - config_.emaAlpha) * sample.emaCpuTime100ns);
        }
        else
        {
            sample.emaCpuTime100ns = currentDelta;
            sample.hasEma = true;
        }
    }
}

std::expected<void, ErrorCode> ThreadTracker::update() noexcept
{
    try
    {
        resetMultiSampleAccumulators();

        const int sampleCount = config_.sampleCount < 1 ? 1 : config_.sampleCount;
        for (int sampleIndex = 0; sampleIndex < sampleCount; ++sampleIndex)
        {
            const auto observeResult = observeOnce();
            if (!observeResult)
            {
                return observeResult;
            }

            if (sampleIndex + 1 < sampleCount)
            {
                std::this_thread::sleep_for(config_.sampleInterval);
            }
        }

        finalizeMultiSample();
        updateCandidateState(std::chrono::steady_clock::now());
        return {};
    }
    catch (const std::bad_alloc&)
    {
        return std::unexpected(ErrorCode::AllocationFailed);
    }
    catch (...)
    {
        return std::unexpected(ErrorCode::InternalError);
    }
}

std::expected<std::vector<ThreadInfo>, ErrorCode>
ThreadTracker::getTopThreads(std::size_t maxCount) const noexcept
{
    try
    {
        std::vector<ThreadInfo> topThreads;
        topThreads.reserve(samples_.size());

        for (const auto& [threadId, sample] : samples_)
        {
            topThreads.push_back(ThreadInfo{
                .deltaCpuTime100ns = sample.deltaCpuTime100ns,
                .emaCpuTime100ns = sample.emaCpuTime100ns,
                .threadId = threadId,
                .isEmaCandidate = emaCandidateThreadId_.has_value() &&
                                  *emaCandidateThreadId_ == threadId,
                .isMainThread = mainThreadId_.has_value() &&
                                *mainThreadId_ == threadId
            });
        }

        std::ranges::sort(
            topThreads,
            [](const ThreadInfo& left, const ThreadInfo& right)
            {
                return left.emaCpuTime100ns > right.emaCpuTime100ns;
            });

        if (topThreads.size() > maxCount)
        {
            topThreads.resize(maxCount);
        }

        return topThreads;
    }
    catch (const std::bad_alloc&)
    {
        return std::unexpected(ErrorCode::AllocationFailed);
    }
    catch (...)
    {
        return std::unexpected(ErrorCode::InternalError);
    }
}

std::optional<DWORD> ThreadTracker::getEmaCandidateThreadId() const noexcept
{
    return emaCandidateThreadId_;
}

std::optional<DWORD> ThreadTracker::getMainThreadId() const noexcept
{
    return mainThreadId_;
}

int ThreadTracker::consumeThreadMigrationCount() noexcept
{
    const int value = threadMigrationCount_;
    threadMigrationCount_ = 0;
    return value;
}

void ThreadTracker::increaseStickinessBy(std::chrono::milliseconds delta) noexcept
{
    if (delta <= std::chrono::milliseconds(0))
    {
        return;
    }

    const auto oldDuration = config_.stickinessDuration;
    config_.stickinessDuration += delta;
    if (config_.stickinessDuration > ThreadTrackerPolicy::kMaxStickinessDuration)
    {
        config_.stickinessDuration = ThreadTrackerPolicy::kMaxStickinessDuration;
    }

    Logger::info(
        "stickiness updated: {} ms -> {} ms (cap={} ms)",
        oldDuration.count(),
        config_.stickinessDuration.count(),
        ThreadTrackerPolicy::kMaxStickinessDuration.count());

    if (oldDuration == ThreadTrackerPolicy::kMaxStickinessDuration &&
        config_.stickinessDuration == ThreadTrackerPolicy::kMaxStickinessDuration)
    {
        Logger::warn(
            "STICKY_UP ignored because stickiness is already capped at {} ms",
            ThreadTrackerPolicy::kMaxStickinessDuration.count());
    }
}

void ThreadTracker::updateCandidateState(
    std::chrono::steady_clock::time_point now) noexcept
{
    std::optional<DWORD> bestThreadId;
    double bestEma = 0.0;

    for (const auto& [threadId, sample] : samples_)
    {
        if (!sample.hasEma)
        {
            continue;
        }

        if (!bestThreadId.has_value() || sample.emaCpuTime100ns > bestEma)
        {
            bestThreadId = threadId;
            bestEma = sample.emaCpuTime100ns;
        }
    }

    if (!bestThreadId.has_value())
    {
        resetCandidateState();
        return;
    }

    if (!emaCandidateThreadId_.has_value() || *emaCandidateThreadId_ != *bestThreadId)
    {
        emaCandidateThreadId_ = *bestThreadId;
        mainThreadId_.reset();
        candidateStartedAt_ = now;
        return;
    }

    if (!candidateStartedAt_.has_value())
    {
        candidateStartedAt_ = now;
        return;
    }

    const auto stableDuration =
        std::chrono::duration_cast<std::chrono::milliseconds>(now - *candidateStartedAt_);

    if (stableDuration >= config_.stickinessDuration)
    {
        if (!mainThreadId_.has_value() || *mainThreadId_ != *bestThreadId)
        {
            if (lastConfirmedMainThreadId_.has_value() && *lastConfirmedMainThreadId_ != *bestThreadId)
            {
                ++threadMigrationCount_;
                Logger::warn(
                    "main thread migration observed: previous confirmed TID {} -> new TID {} (cycleCount={})",
                    *lastConfirmedMainThreadId_,
                    *bestThreadId,
                    threadMigrationCount_);
            }

            mainThreadId_ = *bestThreadId;
            lastConfirmedMainThreadId_ = *bestThreadId;
        }
    }
}

void ThreadTracker::resetCandidateState() noexcept
{
    emaCandidateThreadId_.reset();
    mainThreadId_.reset();
    lastConfirmedMainThreadId_.reset();
    candidateStartedAt_.reset();
}
